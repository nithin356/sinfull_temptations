<p>
  <input type="submit" name="db-reset-submit" value="<?php _e( 'Reset Tables', 'wordpress-database-reset' ) ?>" id="db-reset-submit" class="button-primary" disabled />
  <img src="<?php echo plugins_url( 'assets/images/spinner.gif', dirname( __DIR__ ) ) ?>" alt="loader" id="loader" style="display: none" />
</p>
